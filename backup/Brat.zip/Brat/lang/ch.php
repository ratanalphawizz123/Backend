<?php 


$lang['lang-eng'] = 'English';
$lang['lang-ch'] = 'Chinese';


//index 
$lang['menu'] = '布拉特公司';
$lang['menu'] = '公司';
$lang['menu'] = '凯捷';
?>

?>