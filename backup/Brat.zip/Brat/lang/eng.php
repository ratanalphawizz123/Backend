<?php 


$lang['lang-eng'] = 'English';
$lang['lang-ch'] = 'Chinese';


//index 
$lang['menu'] = 'Brat Company';
$lang['menu'] = 'Company';
$lang['menu'] = 'Capgemini';
?>

?>