<?php

class Config {
    public $host = "localhost"; /* Host name */
    public $user = "alphafk6_phase2b"; /* User */
    public $pass = "test123@pn";   
    public $db = "alphafk6_phase2brat"; /* Database name */
    var $myconn;

    function connect() {

        $con = mysqli_connect($this->host, $this->user, $this->pass, $this->db);
         if (!$con) {
             die('Could not connect to database!');
         } else {
             $this->myconn = $con;
            //echo 'Connection established!';
         }

        return $con;
    }

    function close() {
        mysqli_close($myconn);
        echo 'Connection closed!';
    }
} 

?>
