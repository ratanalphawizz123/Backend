<?php 

 class Ajax extends Controller{
      public function __contruct(){
         parent::__construct();
          // $db=$this->db(); 
   
    }
 public function Company_login()   
{
   	//$db = $this->Database();
   	//$companycode = mysqli_real_escape_string($db,$_POST['companycode']);
   //	$companycode = $_POST['companycode'];
   	$model=$this->model("Dynamic_model");
	$data=array("Language"=>"EN","System_code"=>"3770","System_message"=>"test","System_description"=>"test12");
	$result= $model->getdatafromtable('Company',array("Company_ID"=>$companycode,"REC_status"=>1), $data = "*", $limit = "", $offset= "", $orderby = "", $ordertype = "ASC",$prepare='i');
	print_r($result);die;

   
    
    
    $sql = "SELECT * FROM Company WHERE Company_ID =$companycode AND REC_status=1";// SQL with parameters
    $stmt = $db->prepare($sql); 
    $stmt->bind_param("i", $companycode);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows === 0){
      $errorMessage = GetSystemCode('302');
      $_SESSION['error_msg'] = $errorMessage['System_message'];
      $response=array("status"=>false,"message"=>'false',"data"=>$_SESSION['error_msg']);
     }else{
      $row = $result->fetch_assoc();
      $_SESSION['UserData'] = $row;
      $response=array("status"=>true,"message"=>'success',"data"=>$_SESSION['UserData']);
    }

    echo json_encode($response);
 }
 
 public function Defalut_Company_login()   
{
    
    $db = $this->Database();
    $companycode = mysqli_real_escape_string($db,$_POST['companycode']);
    $sql = "SELECT * FROM Company WHERE Company_ID = '$companycode' AND REC_status=1";// SQL with parameters
    $stmt = $db->prepare($sql); 
    $stmt->bind_param("i", $companycode);
    $stmt->execute();
    $result = $stmt->get_result();
    if($result->num_rows === 0){
      echo $errorMessage = GetSystemCode('302');
      die;
      $data =set_session('error_message',$errorMessage);
      $response=array("status"=>false,"message"=>'false',"data"=>$data);
     }else{
      $row = $result->fetch_assoc();
      setcookie("type", $companycode, time()+3600);
      $data = $row;
      set_session('UserData',$data);
      $response=array("status"=>true,"message"=>'success',"data"=>$data);
    }

    echo json_encode($response);
 }

 
}
?>