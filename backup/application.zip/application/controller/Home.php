<?php
class Home extends Controller{
    
     public function __contruct(){
         parent::__construct();
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
         error_reporting(E_ALL);
        
    }
	 
	public function index(){
		 $this->view("company_login");
	}
	
	public function login(){
	    $this->view("login");
	}
	public function test(){
	    //echo "hi";die;
	    
	$model=$this->model("Dynamic_model");
	$data=array("Language"=>"EN","System_code"=>"3770","System_message"=>"test","System_description"=>"test12");
	$result= $model->getdatafromtable('SystemCode',array("System_code"=>302));
	print_r($result);
	 // echo $model->insert_data('SystemCode',$data);
     // $where=array("id"=>"1","status"=>"Active");
	  //echo $model->updateRowWhere('audio',$where,$data);
	 // echo $model->deletedata('audio',$where);


	}

	
}


?>