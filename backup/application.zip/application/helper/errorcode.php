<?php 

  function Database() {
	 	  //require "application/Config.php";
          $obj= new Config();
          return $obj->connect();
    }
 
   function GetSystemCode($Code){
   
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

            $obj= new Config();
            $db= $obj->connect();
          	$sql = "SELECT * FROM SystemCode where System_code='".$Code."'";
            $stmt = $db->prepare($sql);
            $stmt->bind_param('i', '302');
            $stmt->execute();
            $result = $stmt->get_result();
   }
 
   function set_session($session_name,$data){
            require './application/Sessions.php';
            $obj1= new Sessions();
            return $obj1->set_session_data($session_name,$data);
   }
    
   function get_session($session_name){
            require './application/Sessions.php';
            $obj1= new Sessions();
            return $obj1->session_data($session_name);
   }
    
?>